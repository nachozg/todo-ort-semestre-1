Inicializar();

function Inicializar() {
    document.querySelector("#btn_simulacro1").addEventListener("click", cadenaParOImpar);
    document.querySelector("#btn_simulacro2").addEventListener("click", subirAlArray);

}

function cadenaParOImpar() {
    textoIngresado = document.querySelector("#recibo_texto").value;
    let mostrarTRUEofalse = stringTrueFalse(textoIngresado);
    document.querySelector("#mostrar_resultado").innerHTML = mostrarTRUEofalse;
}

function stringTrueFalse(texto) {
    let cuentaLetras = 0;
    let comprobarLargoToF = false;
    let reciboTxt = "";
    for (let i = 0; i < texto.length; i++) {
        reciboTxt = texto[i];
        cuentaLetras++
    }
    if (cuentaLetras % 2 == 0) {
        comprobarLargoToF = true;
        console.log(comprobarLargoToF)
    } else {
        comprobarLargoToF = false;
        console.log(comprobarLargoToF)
    }
    return comprobarLargoToF
}
miArray = [];


function subirAlArray() {
    textoIngresado = document.querySelector("#recibo_texto2").value;
    miArray.push(textoIngresado);
    textoIngresado = document.querySelector("#recibo_texto2").value = "";
    let dameValores = simulacro2ejercicio(miArray)
    console.log(dameValores)

}
function simulacro2ejercicio (array){
    miArrayParaTrueOrFalse = [];
    let reciboArray = "";
    for (let i = 0; i < array.length; i++) {
         reciboArray = array[i];
         let resultado = stringTrueFalse(array[i])
         
         miArrayParaTrueOrFalse.push(resultado);
         
        
    }
    
    return miArrayParaTrueOrFalse

}
