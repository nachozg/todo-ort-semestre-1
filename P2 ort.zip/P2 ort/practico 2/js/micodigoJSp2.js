inicializar();

function inicializar() {

    document.querySelector("#btnPositive_or_not").addEventListener("click", positiveOrNot);
    document.querySelector("#btnMayor_10").addEventListener("click", alertMayorDiez);
    document.querySelector("#btnMayor_20").addEventListener("click", alertMayorVeinte);
    document.querySelector("#btn_E4").addEventListener("click", cambiarSiNegativo);
    document.querySelector("#btn_E5").addEventListener("click", mostrarSiMayor10Menor20);
    document.querySelector("#btn_E6").addEventListener("click", mostrarSiMultiplo3y7);
    document.querySelector("#btn_E7").addEventListener("click", mostrarSiMayor20oMenorMenos20);
    document.querySelector("#btn_E8").addEventListener("click", mostrarSiMayor30oMenor10);
    document.querySelector("#btn_E9").addEventListener("click", diayTemperatura)
    document.querySelector("#btn_E10").addEventListener("click", restar2NumEnroque);
    document.querySelector("#btn_E13").addEventListener("click", mostrarSiesMultiplo);
    document.querySelector("#btn_E23").addEventListener("click", guardarymostrarEstadisticas);
    document.querySelector("#btn_E11").addEventListener("click", calculadora);
    //document.querySelector("#btn_Procesar_datos").addEventListener("click", mostrarProcesarDatos);
   // document.querySelector("#btn_btn_Cierre_de_caja").addEventListener("click", mostrarCierredeCaja);


}



function positiveOrNot() { // function for alert + o - 

    let numeroingresado = parseInt(document.querySelector("#ingresarNum").value)
    if (numeroingresado >= 0) {

        alert("es positivo")

    } else {

        alert("es negativo")
    }
}

function alertMayorDiez() { // function for alert number > 10

    let numeroingresado = parseInt(document.querySelector("#ingresarNum2").value)
    if (numeroingresado > 10) {

        alert("mayor que 10")


    }
}

function alertMayorVeinte() { // function for alert num > 20

    let numeroingresado = parseInt(document.querySelector("#ingresarNum3").value);
    if (numeroingresado >= 21) {

        document.querySelector("#result_ej_3").innerHTML = "es mayor que 20"

    } else {

        document.querySelector("#result_ej_3").innerHTML = "es menor o igual a 20"
    }
}


function cambiarSiNegativo() { // function for change num < 0 

    let numeroingresado = parseInt(document.querySelector("#ingresarNum4").value);
    if (numeroingresado < 0) {

        let resultado = numeroingresado * -1
        document.querySelector("#result_ej_4").innerHTML = "el resultado es: " + resultado

    } else {

        document.querySelector("#result_ej_4").innerHTML = "el resultado es: " + numeroingresado
    }
}

function mostrarSiMayor10Menor20() { // function for show num if < 20 >10

    let numeroingresado = parseInt(document.querySelector("#ingresarNum5").value);
    if (numeroingresado > 10 && numeroingresado < 20) {


        document.querySelector("#result_ej_5").innerHTML = "el resultado es mayor que 10 y menor que 20";
    } else {

        document.querySelector("#result_ej_5").innerHTML = "el resultado no es mayor que 10 y menor que 20";
    }

}

function mostrarSiMultiplo3y7() { // function for alert num div 7 and 3.

    let numeroingresado = parseInt(document.querySelector("#ingresarNum6").value)
    if (numeroingresado % 7 == 0 && numeroingresado % 3 == 0) {
        alert("es multiplo de 7 y 3.")

    } else {
        alert("No es multiplo de 7 y 3.")
    }
}

function mostrarSiMayor20oMenorMenos20() { // function for alert number > 20 o > -20

    let numeroingresado = parseInt(document.querySelector("#ingresarNum7").value)
    if (numeroingresado > 20) {

        alert("Cumple")
    } else if (numeroingresado < -20) {

        alert("Cumple")
    } else {

        alert("No cumple")
    }
}

function mostrarSiMayor30oMenor10() { // function for alert number > 30 o > 10

    let numeroingresado = parseInt(document.querySelector("#ingresarNum8").value)
    if (numeroingresado > 30) {

        alert("Es mayor que 30")
    } else if (numeroingresado < 10) {

        alert("Es menor que 10")
    } else {

        alert("esta entre 10 y 30")
    }

}


function restar2NumEnroque() { // function for rest two NUm and switch. 
    let numeroingresado1 = parseInt(document.querySelector("#ingresarNum10").value)
    let numeroingresado2 = parseInt(document.querySelector("#ingresarNum210").value)

    if (numeroingresado1 > numeroingresado2) {

        let resultado = numeroingresado1 - numeroingresado2;
        document.querySelector("#result_ej_10").innerHTML = "el resultado es: " + resultado

    } else if (numeroingresado1 < numeroingresado2) {

        let resultado = numeroingresado2 - numeroingresado1;
        document.querySelector("#result_ej_10").innerHTML = "el resultado es: " + resultado

    } else {
        document.querySelector("#result_ej_10").innerHTML = "el resultado es 0"
    }
}

function mostrarSiesMultiplo() { // function for show if multiplo. 
    let numeroingresado1 = parseInt(document.querySelector("#ingresarNum13").value)
    let numeroingresado2 = parseInt(document.querySelector("#ingresarNum213").value)

    if (numeroingresado1 % numeroingresado2 == 0) {

        document.querySelector("#result_ej_13").innerHTML = "Numero 1 es multiplo de numero 2. "

    } else {

        document.querySelector("#result_ej_13").innerHTML = "Numero 1 NO es multiplo de numero 2. "
    }
}


// function for acumular notas sacar promedios y 
let notaminima = Number.POSITIVE_INFINITY;
let notamaxima = Number.NEGATIVE_INFINITY;
let sumaNotas = 0;
let cantidadNotas = 0;
let perdieron = 0; // <70
let salvaron = 0; // > 70
let salvaronmas90 = 0; // > 90

function guardarymostrarEstadisticas() {

    let resultado = "";
    let notaingresada = document.querySelector("#ingresarNota").value;
    let notaingresadaNumerica = parseInt(notaingresada);

    let notaesunNumero = !isNaN(notaingresadaNumerica);

    if (notaesunNumero) {
        if (notaingresadaNumerica >= 0 && notaingresadaNumerica <= 100) {

            cantidadNotas++;
            sumaNotas += notaingresadaNumerica;

            if (notaingresadaNumerica < 70) {
                perdieron++;
            } else {
                salvaron++;
                if (notaingresadaNumerica > 90) {
                    salvaronmas90++;
                }
            }
            if (notaingresadaNumerica < notaminima) {
                notaminima = notaingresadaNumerica;
            }

            if (notaingresadaNumerica > notamaxima) {
                notamaxima = notaingresadaNumerica;
            }
        } else {
            resultado = "La nota debe ser un numero de 0 al 100."
        }

        let promedios = sumaNotas / cantidadNotas;


        resultado = "cantidad que perdieron " + perdieron + "<br></br>"
        resultado += "cantidad que salvaron " + salvaron + "<br></br>"
        resultado += "cantidad que salvaron con muy buena nota " + salvaronmas90 + "<br></br>"
        resultado += "Nota minima " + notaminima + "<br></br>"
        resultado += "Nota maxima " + notamaxima + "<br></br>"
        resultado += "Promedio de notas " + promedios + "<br></br>"




    } else {
        resultado = "la nota ingresada debe ser un numero"
    }

    document.querySelector("#result_ej_23").innerHTML = resultado;

}

let diadelasemana = document.querySelector("#dia").value;
let temperatura = parseInt(document.querySelector("#ingresarTmp").value);

function diayTemperatura() {



    if (diadelasemana = "domingo" && temperatura < 10) {
        alert("descansa abrigate");
    }
    if (diadelasemana = "domingo" && temperatura < 20) {
        alert("descansa, ropa intermedia");
    }
    if (diadelasemana = "domingo " && temperatura > 20) {
        alert("descansa, ponete ropa liviana");
    } else {
        alert("anda a laburar infeliz");
    }


}

function calculadora() {

    let numeroingresado1 = parseInt(document.querySelector("#ingresarNum11").value);
    let numeroingresado2 = parseInt(document.querySelector("#ingresarNum211").value);
    let tipodeOperacion = document.querySelector("#operacionesE11").value;
   
    let resultado;

    switch (tipodeOperacion) {
        case "multiplicacion":
            resultado = numeroingresado1 * numeroingresado2;
            break;
            case "dividir":
            resultado = numeroingresado1 / numeroingresado2;
            break;
            case "sumar":
            resultado = numeroingresado1 + numeroingresado2;
            break;
            case "restar":
            resultado = numeroingresado1 - numeroingresado2;
            break;
            
            
        
    }  

    (document.querySelector("#result_ej_11").innerHTML) = resultado;
}

let MayorCantidadProVendido = Number.NEGATIVE_INFINITY;
let VentasMontoTotalVentasDia = 0;
let CompraActual = 0;

//function mostrarProcesarDatos (){

       let Producto = document.querySelector("#txtProducto").value;
       let Precio = parseFloat(document.querySelector("#txtPrecio").value);
       let Cantidad = parseInt(document.querySelector("#txtCantidadProducto"));
       let resultado = "";

//}

// function mostrarCierredeCaja(){
   


//}